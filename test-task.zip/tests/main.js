import { expect } from 'chai';
import './get'
import './create'

describe('test', function() {
  it('should pass', () => {
    expect('plutio').to.eq('plutio');
  });
});
