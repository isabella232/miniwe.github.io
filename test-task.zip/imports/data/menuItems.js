export default [
    {
        icon: 'icon-check',
        title: 'Tasks',
    },
    {
        icon: 'icon-toolkit',
        title: 'Projects',
    },
    {
        icon: 'icon-coin',
        title: 'Invoices',
    },
    {
        icon: 'icon-signing',
        title: 'Proposals',
    },
    {
        icon: 'icon-user',
        title: 'People',
    },
    {
        icon: 'icon-calendar',
        title: 'Calendar',
    },
    {
        icon: 'icon-inbox',
        title: 'Inbox',
    },
    {
        icon: 'icon-timer',
        title: 'Timesheets',
    },
    {
        icon: 'icon-settings',
        title: 'Settings',
    },
    {
        icon: 'icon-question-mark',
        title: 'Support',
        onClick: () => console.log('support')
    },
]
